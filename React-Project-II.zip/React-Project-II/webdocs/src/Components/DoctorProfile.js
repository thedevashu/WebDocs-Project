import { Component } from "react";

export default class DoctorProfile extends Component{



    render(){
        return(
            <></>
        )
    }
}