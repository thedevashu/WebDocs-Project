import { Component } from "react";

export default class Feedback extends Component{
    render(){
        return{

        }
    }
}