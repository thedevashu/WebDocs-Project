package com.java.webdocs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WebDocsApplication {

	public static void main(String[] args) {
		SpringApplication.run(WebDocsApplication.class, args);
	}

}
