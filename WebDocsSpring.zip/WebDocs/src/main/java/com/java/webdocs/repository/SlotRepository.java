package com.java.webdocs.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.java.webdocs.entity.Slot;

public interface SlotRepository extends JpaRepository<Slot, Integer>{

}
